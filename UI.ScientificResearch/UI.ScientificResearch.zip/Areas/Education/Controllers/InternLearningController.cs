﻿using System.Web.Mvc;

namespace UI.ScientificResearch.Areas.Education.Controllers
{
    /// <summary>
    /// 进修实习
    /// </summary>
    public class InternLearningController : Controller
    {
        //
        // GET: /Education/InternLearning/
        public ActionResult Index()
        {
            return View();
        }
	}
}