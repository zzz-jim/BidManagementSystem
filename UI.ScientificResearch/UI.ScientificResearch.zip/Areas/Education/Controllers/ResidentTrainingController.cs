﻿using System.Web.Mvc;

namespace UI.ScientificResearch.Areas.Education.Controllers
{
    /// <summary>
    /// 住院医培训
    /// </summary>
    public class ResidentTrainingController : Controller
    {
        //
        // GET: /Education/ResidentTraining/
        public ActionResult Index()
        {
            return View();
        }
	}
}