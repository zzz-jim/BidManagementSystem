﻿using System.Web.Mvc;

namespace UI.ScientificResearch.Areas.Education.Controllers
{
    /// <summary>
    /// 网上培训
    /// </summary>
    public class OnlineTrainingController : Controller
    {
        //
        // GET: /Education/OnlineTraining/
        public ActionResult Index()
        {
            return View();
        }
	}
}