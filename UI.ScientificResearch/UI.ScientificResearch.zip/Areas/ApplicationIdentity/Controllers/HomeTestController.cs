﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UI.ScientificResearch.Areas.ApplicationIdentity.Controllers
{
    public class HomeTestController : Controller
    {
        // GET: ApplicationIdentity/HomeTest
        public ActionResult Index()
        {
            return View();
        }
    }
}